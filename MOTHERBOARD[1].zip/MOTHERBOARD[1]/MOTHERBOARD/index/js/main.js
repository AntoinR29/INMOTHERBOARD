let time = 0;
let timerInterval;
let scale = 1;

const startButton = document.getElementById('startButton');
const startScreen = document.getElementById('startScreen');
const timerEl = document.getElementById('timer');
const container = document.getElementById('container-placa');
const piecesDiv = document.getElementById('pieces');
const placa = document.getElementById('placa');
const soundPackSelect = document.getElementById('soundPack');

const soundCorrect = document.getElementById('sound-correct');
const soundWrong = document.getElementById('sound-wrong');
const soundWin = document.getElementById('sound-win');

const soundPaths = {
  default: {
    correct: 'sons/certo.mp3',
    wrong: 'sons/errado.mp3',
    win: 'sons/vitoria.mp3'
  },
  memes: {
    correct: 'sons/meme_acerto.mp3',
    wrong: 'sons/meme_erro.mp3',
    win: 'sons/meme_vitoria.mp3'
  }
};

function setSoundPack(pack) {
  const selected = soundPaths[pack] || soundPaths.default;
  soundCorrect.src = selected.correct;
  soundWrong.src = selected.wrong;
  soundWin.src = selected.win;
}

startButton.addEventListener('click', () => {
  const selectedPack = soundPackSelect.value;
  setSoundPack(selectedPack);

  startScreen.style.display = 'none';
document.getElementById('scaled-wrapper').style.display = 'inline-block';

  timerEl.style.display = 'block';

  timerInterval = setInterval(() => {
    time++;
    timerEl.textContent = `Tempo: ${time}s`;
  }, 1000);
});

window.addEventListener('load', () => {
  imageMapResize();
  scale = placa.getBoundingClientRect().width / placa.naturalWidth;

  document.querySelectorAll('.draggable').forEach(img => {
    img.draggable = true;
    img.addEventListener('dragstart', e => {
      e.dataTransfer.setData('component', img.dataset.component);
    });
  });

document.querySelectorAll('.dropzone-div').forEach(area => {
  area.addEventListener('dragover', e => {
    e.preventDefault();
    area.classList.add('hover');
  });

  area.addEventListener('dragleave', () => {
    area.classList.remove('hover');
  });

  area.addEventListener('drop', e => {
    e.preventDefault();
    area.classList.remove('hover');

    const comp = e.dataTransfer.getData('component');

    if (comp !== area.dataset.component) {
      soundWrong.play();
      return alert('Peça incorreta para esta posição!');
    }

    soundCorrect.play();
    area.classList.add('filled');

    const img = document.querySelector(`img[data-component="${comp}"]`);
    img.style.position = 'absolute';
    img.draggable = false;
    container.appendChild(img);

    const areaW = area.offsetWidth;
    const areaH = area.offsetHeight;
    img.style.width = `${areaW}px`;
    img.style.height = `${areaH}px`;

    const cx = area.offsetLeft + areaW / 2;
    const cy = area.offsetTop + areaH / 2;
    img.style.left = `${cx - img.clientWidth / 2}px`;
    img.style.top = `${cy - img.clientHeight / 2}px`;

    const total = document.querySelectorAll('.dropzone-div').length;
    const preenchidas = document.querySelectorAll('.dropzone-div.filled').length;

    if (preenchidas === total) {
      clearInterval(timerInterval);
      soundWin.play();
      alert(`Parabéns! Você terminou em ${time}s`);
    }
  });
});

});
